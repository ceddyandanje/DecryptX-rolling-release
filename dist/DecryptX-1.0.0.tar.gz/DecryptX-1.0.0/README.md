A simpe hash carcker and password decryptor base on python
intented for Unix environments but can also run on gitbash

update the wordlist.txt entries with your own

You need setuptools library installed to run the installation

you can install it through "pip install setuptools"


