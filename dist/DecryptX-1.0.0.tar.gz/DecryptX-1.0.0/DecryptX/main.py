#!/usr/bin/env python3
import importlib
import subprocess
import urllib.request
import os
#print ("checking and installing requirements")
def install_pip():
    try:
        importlib.import_module('pip')
    except ImportError:
        print("Installing pip...")
        urllib.request.urlretrieve("https://bootstrap.pypa.io/get-pip.py", "get-pip.py")
        subprocess.call([sys.executable, "get-pip.py"])
        os.remove("get-pip.py")
        print("pip installed successfully.")

def install_missing_libraries():
    libraries_to_install = [
        'collections', 'hashlib', 'argparse', 'io', 'os', 'colorama', 'time'
    ]

    for library in libraries_to_install:
        try:
            importlib.import_module(library)
        except ImportError:
            print(f"Installing {library}...")
            subprocess.call(['pip', 'install', library])
            print(f"{library} installed successfully.")
    
install_pip()
install_missing_libraries()
#print("requirements satsified")
import re #regular expressions library for concatination of words and lists
from collections import namedtuple #makes it easy to use data types such as lists and tuples interchangeably
import hashlib
import argparse
import io

import colorama as colorama
from colorama import Fore, Style
import time

# Clear the screen based on the operating system
if os.name == 'posix':  # Unix/Linux/Mac
    os.system('clear')
else:     # for windows
    os.system('cls')
    os.system('clear')



# Function to display the Decrypt-X banner
def display_banner():
    banner = """


    
    
                                                         *****                                  *****    
                                                            $$$                                 $$$
                                                               $$$                           $$$
                                                                  $$$                     $$$
    ____     ____      ____    ____    __________                    $$$               $$$
   |  _ \   /  _ |    /  _ \  |  _ \  |/-------\|                       $$$         $$$
   | / \ |  | |~     |||      || / |       ||                             $$$   $$$
   | \_/ |  | |_/|   ||| _ /  | \_/        ||           ===                  0X0
   |____/   \____\|   \____/  || \/\       ||                              $$$   $$$ 
   ******    *****     ****   ||  \ \     /  \                          $$$         $$$
   ******    *****     ****   **   **     *   *                      $$$               $$$
                                                                  $$$                     $$$
                                                               $$$                           $$$
                                                            $$$                                 $$$
                                                        *****                                   ******

                   
    Decrypt-X - Your Ultimate Decryption Toolkit
    Authored by Cedrick Msila
    This tool is still in the cooking phase



 _______________________(Cedrick)_________________________________________

|
|
|    ~\033[1m I hope you have received the usual lecture from your network Admin
|    ~\033[1m It boils down to two things:
|       \033[91m 1). Dont do something you arent sure of for you will regret later!!
|        2). Refer to 1 above\033[0m\033[32m
|
|
__________________________(ceddyandanje)____________________________________\033[0m


 """

    print(Fore.GREEN + banner + Style.RESET_ALL)



# Function to perform Hash Cracking

def hash_cracker_sha256():
    def hash_password(password, hash_algorithm):
        """Calculate the hash of the password using the specified algorithm."""
        hash_obj = hashlib.new(hash_algorithm)
        hash_obj.update(password.encode('utf-8'))
        return hash_obj.hexdigest()

    def dictionary_attack(target_hash_value, dictionary):
        """Perform the dictionary attack on the provided hash using the given dictionary."""
        for word in dictionary:
            hashed_password = hash_password(word, 'sha256')  # i am using sha256 in this case
            if hashed_password == target_hash_value:
                return word  # Cracked password found!
        
        return None  # Cracked password not found in the dictionary

    def create_wordlist():
        """Allow the user to create their own wordlist interactively."""
        wordlist = []
        print("Enter words one by one (press Enter without typing anything to finish):")
        while True:
            word = input()
            if not word:
                break
            wordlist.append(word)
        return wordlist
    

    #if __name__ == "__main__":

    print("Welcome to Your Password Cracking Tool!")

    target_hash_value = input("Enter the hash to crack: ")
    dictionary_option = input("Do you want to use an existing wordlist? (y/n): ")

    if dictionary_option.lower() == 'y':
        dictionary_file = input("Enter the path to the dictionary file: ")

        with open(dictionary_file, 'r') as f:
            dictionary = [word.strip() for word in f]
    else:
         dictionary = create_wordlist()

    cracked_password = dictionary_attack(target_hash_value, dictionary)

    if cracked_password:
        print(Fore.GREEN + f"Password cracked: {cracked_password}")
    else:
        print("Password not found in the dictionary. Password remains uncracked.")

   
# Function to perform hash cracking based on multiple algorithms
def hash_cracking_multiple():
#Function that performs a brute force attack against hashes of different types and lengths
    print ("Welcome to decryptX hashcracker module")
    print ("Author Cedrick M.")
    hash_pass = input("\033[36mEnter full path or to crack:\033[0m ").lower()
    passlist  = input("\033[36mEnter path to the the dictionary   :\033[0m ")
        
    def sha256(passlist):
        with open(passlist,'r') as f:
            lines = f.readlines()
            for word in lines:
                enc_wrd = word.encode()
                digest = hashlib.sha256(enc_wrd.strip()).hexdigest().lower()

                if digest == hash_pass:
                    print("\033[1;32;40m---------------------------------------------------")
                    print("         Password Found! --> " + word, end = '')
                    print("---------------------------------------------------")
                    break
                else:
                    #print("trying : \033[1;31;40m"+ word + "\n")
                    break


    def md5(passlist):
        with open(passlist,'r') as f:
            lines = f.readlines()
            for word in lines:
                enc_wrd = word.encode()
                digest = hashlib.md5(enc_wrd.strip()).hexdigest().lower()

                if digest == hash_pass:
                    print("\033[1;32;40m---------------------------------------------------")
                    print("         Password Found! --> " + word, end = '')
                    print("---------------------------------------------------")
                    break
                else:
                    #print("trying : \033[1;31;40m"+ word, end = '')
                    break


    def sha1(passlist):
        with open(passlist,'r') as f:
            lines = f.readlines()
            for word in lines:
                enc_wrd = word.encode()
                digest = hashlib.sha1(enc_wrd.strip()).hexdigest().lower()

                if digest == hash_pass:
                    print("\033[1;32;40m---------------------------------------------------")
                    print("         Password Found! --> " + word, end = '')
                    print("---------------------------------------------------")
                    break
                else:
                    #print("trying : \033[1;31;40m"+ word, end = '')
                    break

    def sha512(passlist):
        with open(passlist,'r') as f:
            lines = f.readlines()
            for word in lines:
                enc_wrd = word.encode()
                digest = hashlib.sha512(enc_wrd.strip()).hexdigest().lower()

                if digest == hash_pass:
                    print("\033[1;32;40m---------------------------------------------------")
                    print("         Password Found! --> " + word, end = '')
                    print("---------------------------------------------------")
                    break
                else:
                    #print("trying : \033[1;31;40m"+ word, end = '')
                    break

    def sha384(passlist):
        with open(passlist,'r') as f:
            lines = f.readlines()
            for word in lines:
                enc_wrd = word.encode()
                digest = hashlib.sha384(enc_wrd.strip()).hexdigest().lower()

                if digest == hash_pass:
                    print("\033[1;32;40m---------------------------------------------------")
                    print("          Password Found! --> " + word, end = '')
                    print("---------------------------------------------------")
                    break
                else:
                    #print("trying : \033[1;31;40m"+ word,  end = '')
                    break


    def sha224(passlist):
        with open(passlist,'r') as f:
            lines = f.readlines()
            for word in lines:
                enc_wrd = word.encode()
                digest = hashlib.sha224(enc_wrd.strip()).hexdigest().lower()

                if digest == hash_pass:
                    print("\033[1;32;40m---------------------------------------------------")
                    print("          Password Found! --> " + word, end = '')
                    print("---------------------------------------------------")
                    break
                else:
                    #print("trying : \033[1;31;40m"+ word,  end = '')
                    break

    if len(hash_pass) == 64:
        sha256(passlist)
    elif len(hash_pass) == 32:
        md5(passlist)
    elif len(hash_pass) == 128:
        sha512(passlist)
    elif len(hash_pass) == 40:
        sha1(passlist)
    elif len(hash_pass) == 96:
        sha384(passlist)
    elif len(hash_pass) == 56:
        sha224(passlist)
    else:
        print("Hash not found. Check if its included in md5, sha1, sha224, sha256, sha384, sha512.")


# Function to perform Ransomware Decryption
def password_cracking():
    pass_hash = input("enter hash: ")
    wordlist = input("file name: ")

    flag = 0

    try:
        pass_file = open(wordlist, 'r')
    except:
        print("file not found")
        quit()

    print(hashlib.algorithms_guaranteed)
    algo = input("hashing function: ")

    for word in pass_file:
        word = word.strip()
        encr_wrd = word.encode("utf-8")
        h = hashlib.new(algo)
        h.update(encr_wrd)
        digest = h.hexdigest()
        #print(digest)
        
        if digest == pass_hash:
            print("password found")
            print(word)
            flag = 1
            break

    if flag == 0:
        print("password is not in {}".format(wordlist))

        
def ransomware_decryption():
    print("module still under development")
    print("Author Cedrick M.")

def create_own_hash():
    #module focuses on creating hashes from simple plain text
    print("This module lets you hash your password for trial puporses")

    passw = input("password : ")

    print(hashlib.algorithms_guaranteed)
    algo = input("hashing function: ")

    h = hashlib.new(algo)
    h.update(passw.encode("utf-8"))
    digest = h.hexdigest()

    print("hash: "+ digest)
    print ("copy this hash and paste in the hash cracker prompt")

def check_hash_type():
    print("This module lets you check the type of a hash")
    HashCategory = namedtuple('HashCategory', ['regex', 'modes'])

    HashCategories = [
        HashCategory(
            regex=re.compile(r'^[a-f0-9]{32}(:.+)?$', re.IGNORECASE),
            modes=['MD5']),
        HashCategory(
            regex=re.compile(r'^[a-f0-9]{40}(:.+)?$', re.IGNORECASE),
            modes=['SHA1']),
        HashCategory(
            regex=re.compile(r'^[a-f0-9]{56}$', re.IGNORECASE),
            modes=['SHA224', 'SHA3_224']),
        HashCategory(
            regex=re.compile(r'^[a-f0-9]{64}(:.+)?$', re.IGNORECASE),
            modes=['SHA256', 'SHA3_256', 'blake2s']),
        HashCategory(
            regex=re.compile(r'^[a-f0-9]{96}$', re.IGNORECASE),
            modes=['SHA384', 'SHA3_384']),
        HashCategory(
            regex=re.compile(r'^[a-f0-9]{128}(:.+)?$', re.IGNORECASE),
            modes=['SHA512', 'SHA3_512', 'blake2b']),
    ]

    def identifyHash(hash):
        for category in HashCategories:
            hash = hash.strip()
            if category.regex.match(hash):
                for algo in category.modes:
                    yield algo

    hash = input("submit the hash: ")
    for algo in identifyHash(hash):
        print(algo)
        time.sleep(1)
    else:
        print("kindly input correct algorithm hashed key\n")
    time.sleep(1)

# Main function
def main():
        display_banner()
        

        # Menu for selecting functionalities
        while True:
            print("\nMain Menu:\n")
            print("0. Hash Cracking (sha256)")
            print("1. Hash Cracking (multiple hashes)")
            print("2. Password Cracking")
            print("3. Ransomware Decryption")
            print("4. Create a hash from plain text")
            print("5. check hash type")
            print("99. Exit\n")

            choice = input("\nEnter your choice (0/1/2/3/4/5/99): \n")

            if choice == "1":
                hash_cracking_multiple()
            elif choice == "2":
                password_cracking()
            elif choice == "3":
                ransomware_decryption()
            elif choice == "4":
                create_own_hash()
            elif choice == "5":
                check_hash_type()
            elif choice == "0":
                hash_cracker_sha256()
            elif choice == "99":
                print(Fore.BLUE + "Aspects tested with their solutions" + Style.RESET_ALL)
                print(Fore.BLUE + "Exiting..." + Style.RESET_ALL)            
                break
            else:
                print("Invalid choice. Please select a valid option.")
                

if __name__ == "__main__":
    main()
